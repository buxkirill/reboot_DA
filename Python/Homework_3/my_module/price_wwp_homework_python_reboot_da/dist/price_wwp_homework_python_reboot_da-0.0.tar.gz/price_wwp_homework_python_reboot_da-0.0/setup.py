from setuptools import setup

setup(name='price_wwp_homework_python_reboot_da',
      version='0.0',
      description='Homework_reboot_da',
      packages=['price_wwp_homework_python_reboot_da'],
      author_email='klimkin.k.va@gmail.com',
      zip_safe=False)
